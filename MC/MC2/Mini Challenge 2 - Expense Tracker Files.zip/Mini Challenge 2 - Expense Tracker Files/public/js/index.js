/* You have full freedom on what to write inside this js file */

$(document).ready(function () {
    /* Write your code here. You may also opt out to not use jQuery. 
    If so, you may remove everything in this file and write your js from scratch.*/
});