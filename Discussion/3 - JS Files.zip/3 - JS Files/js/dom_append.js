var element = document.getElementById("div1");
var newP = "\n<p> New Text </p>";
element.innerHTML += newP;
